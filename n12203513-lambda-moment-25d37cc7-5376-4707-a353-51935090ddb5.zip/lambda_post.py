from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException, RequestValidationError
from fastapi.responses import JSONResponse
from mangum import Mangum

from src.middleware.error_handler import error_handler, http_exception_handler, validation_error_handler
from src.routes.post_routes import router as post_router
from src.routes.comment_routes import router as comment_router

app = FastAPI(title="Strobe Post", version="1.0.0")
app.include_router(post_router, prefix="/v1/posts")
app.include_router(comment_router, prefix="/v1/posts/{post_id}/comments")


@app.exception_handler(HTTPException)
async def _http(request: Request, exc: HTTPException) -> JSONResponse:
    return await http_exception_handler(request, exc)


@app.exception_handler(RequestValidationError)
async def _validation(request: Request, exc: RequestValidationError) -> JSONResponse:
    return await validation_error_handler(request, exc)


@app.exception_handler(Exception)
async def _error(request: Request, exc: Exception) -> JSONResponse:
    return await error_handler(request, exc)


handler = Mangum(app)
