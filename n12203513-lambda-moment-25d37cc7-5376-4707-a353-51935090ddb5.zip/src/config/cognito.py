from __future__ import annotations

import base64
import hashlib
import hmac

import boto3

from .settings import settings

_client = None


def get_client():
    """Return a cached Cognito Identity Provider client."""
    global _client
    if _client is None:
        _client = boto3.client("cognito-idp", region_name=settings.aws_region)
    return _client


def secret_hash(username: str) -> str:
    """Compute the Cognito SECRET_HASH for a username using the app client secret."""
    message = (username + settings.cognito_client_id).encode("utf-8")
    key = settings.cognito_client_secret.encode("utf-8")
    digest = hmac.new(key, message, hashlib.sha256).digest()
    return base64.b64encode(digest).decode("utf-8")
