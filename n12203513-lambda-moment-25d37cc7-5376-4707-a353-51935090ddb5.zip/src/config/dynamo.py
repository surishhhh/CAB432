from __future__ import annotations

import boto3

from .settings import settings

_resource = None


def get_resource():
    """Return a cached DynamoDB resource client."""
    global _resource
    if _resource is None:
        _resource = boto3.resource("dynamodb", region_name=settings.aws_region)
    return _resource


def get_table(entity: str):
    """Return the DynamoDB Table object for an entity collection."""
    return get_resource().Table(settings.table_name(entity))
