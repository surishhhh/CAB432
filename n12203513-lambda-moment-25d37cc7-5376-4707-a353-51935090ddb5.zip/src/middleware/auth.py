from __future__ import annotations

import jwt
from fastapi import Depends, Header, HTTPException, status
from jwt import PyJWKClient

from ..config.constants import ROLE_MODERATOR, ROLE_USER
from ..config.settings import settings

MODERATOR_GROUP = "moderators"
_jwks_client: PyJWKClient | None = None


def _get_jwks_client() -> PyJWKClient:
    """Return a cached JWKS client for the Cognito user pool."""
    global _jwks_client
    if _jwks_client is None:
        url = (
            f"https://cognito-idp.{settings.aws_region}.amazonaws.com/"
            f"{settings.cognito_user_pool_id}/.well-known/jwks.json"
        )
        _jwks_client = PyJWKClient(url)
    return _jwks_client


def _verify(token: str) -> dict:
    """Verify a Cognito ID token and return its claims."""
    signing_key = _get_jwks_client().get_signing_key_from_jwt(token)
    issuer = f"https://cognito-idp.{settings.aws_region}.amazonaws.com/{settings.cognito_user_pool_id}"
    claims = jwt.decode(
        token,
        signing_key.key,
        algorithms=["RS256"],
        audience=settings.cognito_client_id,
        issuer=issuer,
    )
    if claims.get("token_use") != "id":
        raise ValueError("Not an ID token")
    return claims


async def authenticate(authorization: str | None = Header(default=None)) -> dict:
    """Validate a bearer token and return the authenticated user context."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")

    token = authorization.removeprefix("Bearer ").strip()
    try:
        claims = _verify(token)
    except Exception as exc:  # translated to 401
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token") from exc

    groups = claims.get("cognito:groups", []) or []
    role = ROLE_MODERATOR if MODERATOR_GROUP in groups else ROLE_USER
    return {
        "userId": claims["sub"],
        "userRole": role,
        "username": claims.get("email") or claims.get("cognito:username"),
    }


async def optional_authenticate(authorization: str | None = Header(default=None)) -> dict | None:
    """Return authenticated context when a valid token is provided, else None."""
    if not authorization:
        return None
    try:
        return await authenticate(authorization)
    except HTTPException:
        return None


async def require_moderator(current_user: dict = Depends(authenticate)) -> dict:
    """Require moderator group membership."""
    if current_user.get("userRole") != ROLE_MODERATOR:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Moderator access required")
    return current_user
