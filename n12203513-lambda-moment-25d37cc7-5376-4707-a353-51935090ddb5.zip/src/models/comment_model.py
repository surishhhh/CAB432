from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings
from ..utils.id_generator import generate_id


def _table():
    """Return the comments DynamoDB table."""
    return get_table("comments")


def find_comment_by_id(comment_id: str) -> dict[str, Any] | None:
    """Find a comment by id."""
    return _table().get_item(Key={"id": comment_id}).get("Item")


def get_comments_by_post_id(post_id: str) -> list[dict[str, Any]]:
    """Return a post's comments, oldest first."""
    items = _table().scan(FilterExpression=Attr("postId").eq(post_id)).get("Items", [])
    items.sort(key=lambda comment: comment["createdAt"])
    return items


def create_comment(comment_data: dict[str, Any]) -> dict[str, Any]:
    """Create a comment and return it."""
    now = settings.now_iso()
    comment = {
        "id": comment_data.get("id", generate_id()),
        "postId": comment_data["postId"],
        "userId": comment_data["userId"],
        "text": comment_data["text"],
        "createdAt": comment_data.get("createdAt", now),
        "updatedAt": comment_data.get("updatedAt", now),
    }
    _table().put_item(Item=comment)
    return dict(comment)


def delete_comment(comment_id: str) -> bool:
    """Delete a comment."""
    if not _table().get_item(Key={"id": comment_id}).get("Item"):
        return False
    _table().delete_item(Key={"id": comment_id})
    return True


def get_comment_count_by_post_id(post_id: str) -> int:
    """Return a post's comment count."""
    return len(_table().scan(FilterExpression=Attr("postId").eq(post_id)).get("Items", []))


def delete_comments_by_post_id(post_id: str) -> None:
    """Delete all comments on a post."""
    for comment in _table().scan(FilterExpression=Attr("postId").eq(post_id)).get("Items", []):
        _table().delete_item(Key={"id": comment["id"]})
