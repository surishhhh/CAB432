from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings
from ..utils.id_generator import generate_id


def _table():
    """Return the follows DynamoDB table."""
    return get_table("follows")


def find_follow(follower_id: str, followee_id: str) -> dict[str, Any] | None:
    """Find a follow relationship."""
    items = _table().scan(
        FilterExpression=Attr("followerId").eq(follower_id) & Attr("followeeId").eq(followee_id)
    ).get("Items", [])
    return items[0] if items else None


def is_following(follower_id: str | None, followee_id: str) -> bool:
    """Return whether follower follows followee."""
    if not follower_id:
        return False
    return find_follow(follower_id, followee_id) is not None


def get_following(user_id: str) -> list[str]:
    """Return the IDs a user follows."""
    items = _table().scan(FilterExpression=Attr("followerId").eq(user_id)).get("Items", [])
    return [follow["followeeId"] for follow in items]


def get_followers(user_id: str) -> list[str]:
    """Return the IDs following a user."""
    items = _table().scan(FilterExpression=Attr("followeeId").eq(user_id)).get("Items", [])
    return [follow["followerId"] for follow in items]


def get_following_count(user_id: str) -> int:
    """Return how many users a user follows."""
    return len(_table().scan(FilterExpression=Attr("followerId").eq(user_id)).get("Items", []))


def get_follower_count(user_id: str) -> int:
    """Return how many users follow a user."""
    return len(_table().scan(FilterExpression=Attr("followeeId").eq(user_id)).get("Items", []))


def create_follow(follow_data: dict[str, Any]) -> dict[str, Any]:
    """Create a follow relationship and return it."""
    follow = {
        "id": follow_data.get("id", generate_id()),
        "followerId": follow_data["followerId"],
        "followeeId": follow_data["followeeId"],
        "createdAt": follow_data.get("createdAt", settings.now_iso()),
    }
    _table().put_item(Item=follow)
    return dict(follow)


def remove_follow(follower_id: str, followee_id: str) -> bool:
    """Remove a follow relationship."""
    follow = find_follow(follower_id, followee_id)
    if not follow:
        return False
    _table().delete_item(Key={"id": follow["id"]})
    return True


def remove_follows_by_user_id(user_id: str) -> None:
    """Remove all follows involving a user."""
    items = _table().scan(
        FilterExpression=Attr("followerId").eq(user_id) | Attr("followeeId").eq(user_id)
    ).get("Items", [])
    for follow in items:
        _table().delete_item(Key={"id": follow["id"]})
