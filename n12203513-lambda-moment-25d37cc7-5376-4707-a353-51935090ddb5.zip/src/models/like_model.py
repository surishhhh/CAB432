from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings
from ..utils.id_generator import generate_id


def _table():
    """Return the likes DynamoDB table."""
    return get_table("likes")


def find_like(post_id: str, user_id: str) -> dict[str, Any] | None:
    """Find a like by post and user."""
    items = _table().scan(
        FilterExpression=Attr("postId").eq(post_id) & Attr("userId").eq(user_id)
    ).get("Items", [])
    return items[0] if items else None


def has_user_liked_post(post_id: str, user_id: str | None) -> bool:
    """Return whether a user has liked a post."""
    if not user_id:
        return False
    return find_like(post_id, user_id) is not None


def get_like_count_by_post_id(post_id: str) -> int:
    """Return a post's like count."""
    return len(_table().scan(FilterExpression=Attr("postId").eq(post_id)).get("Items", []))


def create_like(like_data: dict[str, Any]) -> dict[str, Any]:
    """Create a like and return it."""
    like = {
        "id": like_data.get("id", generate_id()),
        "postId": like_data["postId"],
        "userId": like_data["userId"],
        "createdAt": like_data.get("createdAt", settings.now_iso()),
    }
    _table().put_item(Item=like)
    return dict(like)


def remove_like(post_id: str, user_id: str) -> bool:
    """Remove a user's like on a post."""
    like = find_like(post_id, user_id)
    if not like:
        return False
    _table().delete_item(Key={"id": like["id"]})
    return True


def remove_likes_by_post_id(post_id: str) -> None:
    """Remove all likes on a post."""
    for like in _table().scan(FilterExpression=Attr("postId").eq(post_id)).get("Items", []):
        _table().delete_item(Key={"id": like["id"]})


def remove_likes_by_user_id(user_id: str) -> None:
    """Remove all likes by a user."""
    for like in _table().scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", []):
        _table().delete_item(Key={"id": like["id"]})
