from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings
from ..utils.id_generator import generate_id


def _table():
    """Return the moments DynamoDB table."""
    return get_table("moments")


def create_moment(moment_data: dict[str, Any]) -> dict[str, Any]:
    """Create a moment and return it."""
    now = settings.now_iso()
    moment = {
        "id": moment_data.get("id", generate_id()),
        "userId": moment_data["userId"],
        "imageUrl": moment_data["imageUrl"],
        "caption": moment_data.get("caption", ""),
        "status": moment_data.get("status", "active"),
        "hiddenBy": moment_data.get("hiddenBy"),
        "hiddenAt": moment_data.get("hiddenAt"),
        "archivedAt": moment_data.get("archivedAt"),
        "createdAt": moment_data.get("createdAt", now),
        "expiresAt": moment_data.get("expiresAt"),
        "updatedAt": moment_data.get("updatedAt", now),
    }
    _table().put_item(Item=moment)
    return dict(moment)


def find_moment_by_id(moment_id: str) -> dict[str, Any] | None:
    """Find a moment by id."""
    return _table().get_item(Key={"id": moment_id}).get("Item")


def update_moment(moment_id: str, updates: dict[str, Any]) -> dict[str, Any] | None:
    """Update a moment and return it."""
    moment = _table().get_item(Key={"id": moment_id}).get("Item")
    if not moment:
        return None
    for key, value in updates.items():
        if value is not None and key != "id":
            moment[key] = value
    moment["updatedAt"] = settings.now_iso()
    _table().put_item(Item=moment)
    return dict(moment)


def delete_moment(moment_id: str) -> bool:
    """Delete a moment."""
    if not _table().get_item(Key={"id": moment_id}).get("Item"):
        return False
    _table().delete_item(Key={"id": moment_id})
    return True


def get_moments_by_user_ids(user_ids: list[str]) -> list[dict[str, Any]]:
    """Return moments from a set of users, newest first."""
    if not user_ids:
        return []
    items = [moment for moment in _table().scan().get("Items", []) if moment["userId"] in user_ids]
    items.sort(key=lambda moment: moment["createdAt"], reverse=True)
    return items


def get_moments_by_user_id(user_id: str) -> list[dict[str, Any]]:
    """Return a single user's moments, newest first."""
    return get_moments_by_user_ids([user_id])


def delete_moments_by_user_id(user_id: str) -> None:
    """Delete all of a user's moments."""
    for moment in _table().scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", []):
        _table().delete_item(Key={"id": moment["id"]})
