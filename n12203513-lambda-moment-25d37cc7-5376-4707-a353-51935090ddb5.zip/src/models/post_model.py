from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings
from ..utils.id_generator import generate_id


def _table():
    """Return the posts DynamoDB table."""
    return get_table("posts")


def find_post_by_id(post_id: str) -> dict[str, Any] | None:
    """Find a post by id."""
    return _table().get_item(Key={"id": post_id}).get("Item")


def get_posts_by_user_id(user_id: str, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
    """Return a user's posts, newest first."""
    items = _table().scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", [])
    items.sort(key=lambda post: post["createdAt"], reverse=True)
    return items[offset:offset + limit]


def get_all_posts(limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
    """Return all posts, newest first."""
    items = _table().scan().get("Items", [])
    items.sort(key=lambda post: post["createdAt"], reverse=True)
    return items[offset:offset + limit]


def create_post(post_data: dict[str, Any]) -> dict[str, Any]:
    """Create a post and return it."""
    now = settings.now_iso()
    post = {
        "id": post_data.get("id", generate_id()),
        "userId": post_data["userId"],
        "title": post_data["title"],
        "description": post_data.get("description", ""),
        "images": list(post_data.get("images", [])),
        "status": post_data.get("status", "active"),
        "hiddenBy": post_data.get("hiddenBy"),
        "hiddenAt": post_data.get("hiddenAt"),
        "createdAt": post_data.get("createdAt", now),
        "updatedAt": post_data.get("updatedAt", now),
    }
    _table().put_item(Item=post)
    return dict(post)


def update_post(post_id: str, updates: dict[str, Any]) -> dict[str, Any] | None:
    """Update a post and return it."""
    post = _table().get_item(Key={"id": post_id}).get("Item")
    if not post:
        return None
    for key, value in updates.items():
        if value is not None and key != "id":
            post[key] = value
    post["updatedAt"] = settings.now_iso()
    _table().put_item(Item=post)
    return dict(post)


def delete_post(post_id: str) -> bool:
    """Delete a post."""
    if not _table().get_item(Key={"id": post_id}).get("Item"):
        return False
    _table().delete_item(Key={"id": post_id})
    return True


def get_posts_from_users(user_ids: list[str], limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
    """Return posts from a set of users, newest first."""
    if not user_ids:
        return []
    items = [post for post in _table().scan().get("Items", []) if post["userId"] in user_ids]
    items.sort(key=lambda post: post["createdAt"], reverse=True)
    return items[offset:offset + limit]


def get_post_count_by_user_id(user_id: str) -> int:
    """Return a user's post count."""
    return len(_table().scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", []))


def delete_posts_by_user_id(user_id: str) -> None:
    """Delete all of a user's posts."""
    for post in _table().scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", []):
        _table().delete_item(Key={"id": post["id"]})
