from __future__ import annotations

from typing import Any

from boto3.dynamodb.conditions import Attr

from ..config.dynamo import get_table
from ..config.settings import settings


def _table():
    """Return the users DynamoDB table."""
    return get_table("users")


def sanitize_user(user: dict[str, Any] | None) -> dict[str, Any] | None:
    """Return a user object without sensitive fields."""
    if user is None:
        return None
    sanitized = dict(user)
    sanitized.pop("password", None)
    return sanitized


def find_user_by_id(user_id: str) -> dict[str, Any] | None:
    """Find a user by id."""
    item = _table().get_item(Key={"id": user_id}).get("Item")
    return sanitize_user(item)


def find_user_auth_by_email(email: str) -> dict[str, Any] | None:
    """Find a raw user record by email (auth is handled by Cognito, kept for compatibility)."""
    items = _table().scan(FilterExpression=Attr("email").eq(email)).get("Items", [])
    return items[0] if items else None


def get_all_users() -> list[dict[str, Any]]:
    """Return all users."""
    items = _table().scan().get("Items", [])
    return [sanitize_user(item) for item in items]


def create_user(user_data: dict[str, Any]) -> dict[str, Any]:
    """Create a user row. `id` must be the Cognito sub."""
    now = settings.now_iso()
    user = {
        "id": user_data["id"],
        "username": user_data["username"],
        "email": user_data["email"],
        "role": user_data.get("role", "user"),
        "createdAt": user_data.get("createdAt", now),
        "updatedAt": user_data.get("updatedAt", now),
    }
    _table().put_item(Item=user)
    return sanitize_user(dict(user))


def update_user(user_id: str, updates: dict[str, Any]) -> dict[str, Any] | None:
    """Update a user and return the updated record."""
    existing = _table().get_item(Key={"id": user_id}).get("Item")
    if not existing:
        return None
    existing.update({k: v for k, v in updates.items() if v is not None})
    existing["updatedAt"] = settings.now_iso()
    _table().put_item(Item=existing)
    return sanitize_user(dict(existing))


def delete_user(user_id: str) -> bool:
    """Delete a user row."""
    if not _table().get_item(Key={"id": user_id}).get("Item"):
        return False
    _table().delete_item(Key={"id": user_id})
    return True


def username_exists(username: str) -> bool:
    """Return whether a username exists."""
    items = _table().scan(FilterExpression=Attr("username").eq(username)).get("Items", [])
    return len(items) > 0


def email_exists(email: str) -> bool:
    """Return whether an email exists."""
    items = _table().scan(FilterExpression=Attr("email").eq(email)).get("Items", [])
    return len(items) > 0


def search_users(query: str, limit: int = 10) -> list[dict[str, Any]]:
    """Search users by username substring."""
    if not query:
        return get_all_users()[:limit]
    items = _table().scan(FilterExpression=Attr("username").contains(query)).get("Items", [])
    return [sanitize_user(item) for item in items[:limit]]


def _delete_matching(table, filter_expr) -> None:
    """Delete all items in a table matching a filter (by id primary key)."""
    for item in table.scan(FilterExpression=filter_expr).get("Items", []):
        table.delete_item(Key={"id": item["id"]})


def delete_user_with_cascade(user_id: str) -> bool:
    """Delete a user and all their related records across tables."""
    if not _table().get_item(Key={"id": user_id}).get("Item"):
        return False

    posts_tbl = get_table("posts")
    comments_tbl = get_table("comments")
    posts = posts_tbl.scan(FilterExpression=Attr("userId").eq(user_id)).get("Items", [])
    for post in posts:
        _delete_matching(comments_tbl, Attr("postId").eq(post["id"]))
        posts_tbl.delete_item(Key={"id": post["id"]})

    _delete_matching(comments_tbl, Attr("userId").eq(user_id))
    _delete_matching(get_table("likes"), Attr("userId").eq(user_id))
    follows_tbl = get_table("follows")
    _delete_matching(follows_tbl, Attr("followerId").eq(user_id))
    _delete_matching(follows_tbl, Attr("followeeId").eq(user_id))
    _delete_matching(get_table("moments"), Attr("userId").eq(user_id))

    _table().delete_item(Key={"id": user_id})
    return True
