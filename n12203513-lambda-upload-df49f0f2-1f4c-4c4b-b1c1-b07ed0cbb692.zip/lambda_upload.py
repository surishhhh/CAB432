from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException, RequestValidationError
from fastapi.responses import JSONResponse
from mangum import Mangum

from src.middleware.error_handler import error_handler, http_exception_handler, validation_error_handler
from src.routes.upload_routes import router as upload_router

app = FastAPI(title="Strobe Upload", version="1.0.0")
app.include_router(upload_router, prefix="/v1/uploads")


@app.exception_handler(HTTPException)
async def _http(request: Request, exc: HTTPException) -> JSONResponse:
    return await http_exception_handler(request, exc)


@app.exception_handler(RequestValidationError)
async def _validation(request: Request, exc: RequestValidationError) -> JSONResponse:
    return await validation_error_handler(request, exc)


@app.exception_handler(Exception)
async def _error(request: Request, exc: Exception) -> JSONResponse:
    return await error_handler(request, exc)


handler = Mangum(app)
