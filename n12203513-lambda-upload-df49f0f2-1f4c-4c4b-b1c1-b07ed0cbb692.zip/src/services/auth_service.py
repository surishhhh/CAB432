from __future__ import annotations

import logging
import shutil
import uuid
from pathlib import Path

import jwt

from ..config.constants import ROLE_MODERATOR, ROLE_USER
from ..config.cognito import get_client, secret_hash
from ..config.settings import settings
from ..errors import conflict_error, forbidden_error, not_found_error, unauthorised_error, validation_error
from ..models.user_model import create_user, delete_user_with_cascade, email_exists, find_user_by_id, get_all_users, search_users
from ..utils.enrichment import enrich_user, enrich_users
from ..utils.validation import validate_email, validate_password, validate_role

MODERATOR_GROUP = "moderators"

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def _decode(id_token: str) -> dict:
    """Decode an ID token's claims without verifying the signature."""
    return jwt.decode(id_token, options={"verify_signature": False})


def _authenticate(email: str, password: str) -> tuple[str, dict]:
    """Authenticate against Cognito and return (id_token, claims)."""
    client = get_client()
    try:
        resp = client.admin_initiate_auth(
            UserPoolId=settings.cognito_user_pool_id,
            ClientId=settings.cognito_client_id,
            AuthFlow="ADMIN_USER_PASSWORD_AUTH",
            AuthParameters={
                "USERNAME": email,
                "PASSWORD": password,
                "SECRET_HASH": secret_hash(email),
            },
        )
    except client.exceptions.NotAuthorizedException as exc:
        logger.error("AUTH NotAuthorized email=%r: %s", email, exc)
        raise unauthorised_error("Invalid email or password")
    except client.exceptions.UserNotFoundException as exc:
        logger.error("AUTH UserNotFound email=%r: %s", email, exc)
        raise unauthorised_error("Invalid email or password")
    except Exception as exc:
        logger.error("AUTH UNEXPECTED email=%r type=%s: %s", email, type(exc).__name__, exc)
        raise

    if "AuthenticationResult" not in resp:
        logger.error("AUTH no AuthenticationResult, challenge=%s", resp.get("ChallengeName"))
        raise unauthorised_error("Invalid email or password")

    id_token = resp["AuthenticationResult"]["IdToken"]
    return id_token, _decode(id_token)


def _set_initial_password(email: str, temp_password: str, new_password: str) -> tuple[str, dict]:
    """Complete the NEW_PASSWORD_REQUIRED challenge to set a permanent password and get tokens."""
    client = get_client()
    init = client.admin_initiate_auth(
        UserPoolId=settings.cognito_user_pool_id,
        ClientId=settings.cognito_client_id,
        AuthFlow="ADMIN_USER_PASSWORD_AUTH",
        AuthParameters={
            "USERNAME": email,
            "PASSWORD": temp_password,
            "SECRET_HASH": secret_hash(email),
        },
    )
    if init.get("ChallengeName") == "NEW_PASSWORD_REQUIRED":
        resp = client.admin_respond_to_auth_challenge(
            UserPoolId=settings.cognito_user_pool_id,
            ClientId=settings.cognito_client_id,
            ChallengeName="NEW_PASSWORD_REQUIRED",
            Session=init["Session"],
            ChallengeResponses={
                "USERNAME": email,
                "NEW_PASSWORD": new_password,
                "SECRET_HASH": secret_hash(email),
            },
        )
        id_token = resp["AuthenticationResult"]["IdToken"]
    else:
        id_token = init["AuthenticationResult"]["IdToken"]
    return id_token, _decode(id_token)


def register_user(user_data: dict) -> dict:
    """Register a new user in Cognito and DynamoDB, returning user + token."""
    email = user_data.get("email")
    password = user_data.get("password")
    requested_role = user_data.get("role", ROLE_USER)
    logger.info("REGISTER keys=%s email=%r pw_present=%s", list(user_data.keys()), email, bool(password))

    for validator in (validate_email(email), validate_password(password)):
        if not validator["valid"]:
            raise validation_error(str(validator["error"]))
    role_validation = validate_role(requested_role)
    if not role_validation["valid"]:
        raise validation_error(str(role_validation["error"]))
    if email_exists(email):
        raise conflict_error("Email already exists")

    client = get_client()
    temp_password = "Aa1!" + uuid.uuid4().hex[:16]
    try:
        resp = client.admin_create_user(
            UserPoolId=settings.cognito_user_pool_id,
            Username=email,
            UserAttributes=[
                {"Name": "email", "Value": email},
                {"Name": "email_verified", "Value": "true"},
            ],
            TemporaryPassword=temp_password,
            MessageAction="SUPPRESS",
        )
    except client.exceptions.UsernameExistsException:
        raise conflict_error("Email already exists")

    sub = next((attr["Value"] for attr in resp["User"]["Attributes"] if attr["Name"] == "sub"), None)

    if requested_role == ROLE_MODERATOR:
        client.admin_add_user_to_group(
            UserPoolId=settings.cognito_user_pool_id, Username=email, GroupName=MODERATOR_GROUP
        )

    try:
        token, _ = _set_initial_password(email, temp_password, password)
    except (client.exceptions.InvalidPasswordException, client.exceptions.InvalidParameterException) as exc:
        logger.error("REGISTER set-password failed email=%r: %s", email, exc)
        client.admin_delete_user(UserPoolId=settings.cognito_user_pool_id, Username=email)
        raise validation_error("Password does not meet requirements")

    user = create_user({"id": sub, "username": email, "email": email, "role": requested_role})
    return {"user": user, "token": token}


def login_user(credentials: dict) -> dict:
    """Authenticate a user via Cognito and return user + token."""
    
    email = credentials.get("email") or credentials.get("username")
    password = credentials.get("password")
    logger.info("LOGIN keys=%s email=%r pw_present=%s", list(credentials.keys()), email, bool(password))
    if not email or not password:
        raise unauthorised_error("Invalid email or password")

    token, claims = _authenticate(email, password)
    sub = claims["sub"]
    groups = claims.get("cognito:groups", []) or []
    role = ROLE_MODERATOR if MODERATOR_GROUP in groups else ROLE_USER

    user = find_user_by_id(sub)
    if not user:
        user = create_user({"id": sub, "username": email, "email": email, "role": role})
    return {"user": user, "token": token}


def get_user_profile(user_id: str, current_user_id: str | None = None) -> dict:
    """Return one enriched user profile by ID."""
    user = find_user_by_id(user_id)
    if not user:
        raise not_found_error("User not found")
    return enrich_user(user, current_user_id)


def list_users(query: str = "", limit: int = 20, current_user_id: str | None = None) -> list[dict]:
    """Return an enriched user list."""
    limit = max(1, min(int(limit), 100))
    users = search_users(query or "", limit=limit) if query else get_all_users()[:limit]
    return enrich_users(users, current_user_id)


def delete_user_account(authenticated_user_id: str, target_user_id: str) -> None:
    """Delete the authenticated user's account from Cognito and DynamoDB."""
    if authenticated_user_id != target_user_id:
        raise forbidden_error("You can only delete your own account")

    if not delete_user_with_cascade(target_user_id):
        raise not_found_error("User not found")

    client = get_client()
    try:
        client.admin_delete_user(UserPoolId=settings.cognito_user_pool_id, Username=target_user_id)
    except client.exceptions.UserNotFoundException:
        pass

    user_uploads_dir = Path(settings.uploads_dir) / target_user_id
    if user_uploads_dir.exists():
        shutil.rmtree(user_uploads_dir, ignore_errors=True)
