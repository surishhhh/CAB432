from __future__ import annotations

import boto3
from botocore.config import Config

from ..config.settings import settings
from ..errors import validation_error
from ..utils.id_generator import generate_short_id

UPLOAD_URL_EXPIRY = 300   # 5 minutes (User Story 7)
DOWNLOAD_URL_EXPIRY = 300  # 5 minutes (User Story 8)

_s3 = None


def _client():
    """Return a cached S3 client using SigV4 presigning."""
    global _s3
    if _s3 is None:
        _s3 = boto3.client(
            "s3",
            region_name=settings.aws_region,
            config=Config(signature_version="s3v4"),
        )
    return _s3


def _object_key(user_id: str, post_id: str, file_id: str) -> str:
    """Object key tied to user and post (no prefix, so it starts with the user id)."""
    return f"{user_id}/{post_id}/{file_id}"


def get_upload_url(user_id: str, post_id: str) -> dict:
    """Issue a short-lived presigned S3 PUT URL for a specific object."""
    if not post_id:
        raise validation_error("Post ID is required")
    file_id = generate_short_id()
    key = _object_key(user_id, post_id, file_id)
    url = _client().generate_presigned_url(
        "put_object",
        Params={"Bucket": settings.s3_bucket, "Key": key},
        ExpiresIn=UPLOAD_URL_EXPIRY,
    )
    return {"uploadUrl": url, "fileId": file_id, "key": key}


def get_download_url(key: str | None) -> str | None:
    """Issue a short-lived presigned S3 GET URL for an object key."""
    if not key:
        return None
    return _client().generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.s3_bucket, "Key": key},
        ExpiresIn=DOWNLOAD_URL_EXPIRY,
    )


async def store_uploaded_file(user_id: str, post_id: str, file_id: str, file) -> dict:
    """Direct server-side upload is not used in the cloud flow."""
    raise validation_error("Use the presigned upload URL to upload directly to storage")


def delete_uploaded_file(file_id: str) -> bool:
    return False


def get_file_url(file_id: str) -> str | None:
    return None
